# Welcome to Decrypt It!
This game improves your cryptographic and pattern recognition skills.
You will be given a message encrypted in a simple cipher.
Your task is to decrypt the message, case sensitive.
Every message correct is +1 point. Every incorrect is -1 point. Every skipped is 0 points.
Enter a blank line to skip.
Enter 'qx' to quit.
Good luck!

_Made for the 2022 CSP Performance Task._
